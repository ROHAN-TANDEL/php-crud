<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center>
	<h3>login up</h3>
	<form action="employee_retrive.php" method="POST">
		email:
		<br><input type="email" name="email" placeholder="email">
		<br>
		<br>Password:
		<br><input type="password" name="password" placeholder="password">
		<br>
		<br><button>submit</button>
		<br>
		<br>
	</form>
</center>
</body>
</html>