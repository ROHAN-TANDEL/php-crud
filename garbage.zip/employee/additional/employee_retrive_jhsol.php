<!-- employee_retrive.php -->
<?php
session_start();

error_reporting(E_ERROR | E_PARSE);
include_once 'basic_db_connection.php';
$email = $_POST['email'];
$password = $_POST['password'];

$result = mysqli_query($conn,"SELECT * FROM employee WHERE email='".$email."' AND password='".$password."'");
if (!$result) {
	echo mysqli_error($conn);
	session_unset();
	session_destroy();
	//mysqli_close($conn);
	header('Location:login.php');
} else {
	$_SESSION['logged_in_user'] = $_POST['email'];
}

?>

<!DOCTYPE html>
<html>
<head>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<title> Retrive data</title>
<style type="text/css">
table * input {
	border: none;
}
table {
font-family: arial, sans-serif;
border-collapse: collapse;
width: 100%;
}
td, th {
border: 1px solid #dddddd;
text-align: left;
padding: 8px;
}
tr:nth-child(even) {
background-color: white;
}
</style>
</head>

<body>
	<form name="formSubmit" id="formSubmit"  action="" enctype="multipart/form-data">
<table id="form_table">
<tr>
<td>First Name</td>
<td>Father Name</td>
<td>Email id</td>
<td>User Name</td>
<td>Phone Number</td>

<td>Education </td>
<td>Gender </td>
<td>DOB</td>
<td>Address</td>
<td>Profile Pic</td>
</tr>
<?php
$i=0;

if ($_SESSION['logged_in_user']) {

while($row = mysqli_fetch_array($result)) {

if($i%2==0)
$classname="even";
else
$classname="odd";

?>

<tr id="<?php echo $row['userid'];?>" class="<?php if(isset($classname)) echo $classname;?>">
<td class="<?php echo $row['userid'];?>"><input id="frow<?php echo $row['userid']; ?>" type="text" name="first_name" value="<?php echo $row["first_name"]; ?>"/></td>

<td class="<?php echo $row['userid'];?>"><input id="lrow<?php echo $row['userid']; ?>" type="text" name="last_name" value="<?php echo $row["father_name"]; ?>"/></td>

<td class="<?php echo $row['userid'];?>"><input id="crow<?php echo $row['userid']; ?>" type="name" name="city_name" value="<?php echo $row["email"]; ?>"/></td>

<td class="<?php echo $row['userid'];?>"><input id="erow<?php echo $row['userid']; ?>" type="email" name="email" value="<?php echo $row["user_name"]; ?>"></td>

<td class="<?php echo $row['userid'];?>"><input id="erow<?php echo $row['userid']; ?>" type="email" name="email" value="<?php echo $row["phone_number"]; ?>"></td>

<td class="<?php echo $row['userid'];?>"><input id="erow<?php echo $row['userid']; ?>" type="email" name="email" value="<?php echo $row["education"]; ?>"></td>

<td class="<?php echo $row['userid'];?>"><input id="erow<?php echo $row['userid']; ?>" type="email" name="email" value="<?php echo $row["gender"]; ?>"></td>

<td class="<?php echo $row['userid'];?>"><input id="erow<?php echo $row['userid']; ?>" type="email" name="email" value="<?php echo $row["date_of_birth"]; ?>"></td>

<td class="<?php echo $row['userid'];?>"><input id="erow<?php echo $row['userid']; ?>" type="email" name="email" value="<?php echo $row["address"]; ?>"></td>


<td class="<?php echo $row['userid']?>"> 
<?php 

$user_id = $row['userid'];

$res=mysqli_query($conn,"SELECT * FROM image WHERE name=$user_id");

$row1=mysqli_fetch_array($res);

if ($row1['image']=="") {
	$a ='<img src="'. "http://localhost/ads.jpg".'" height="50" width="50"/>';
} else {
$a ='<img src="data:image/jpeg;base64,'.base64_encode($row1['image'] ).'" height="50" width="50"/>';
}
?>
<?php echo $a; ?>
</td>

</tr>
<?php
$i++;
}
if ($i==0) {
	echo "<a href='login.php'><h1>pls signup</h1></a>";
}
} else {
	echo "<a href='login.php'><h1>pls login first</h1></a>";
}
?>
</table>
</form>
</body>
</html>
