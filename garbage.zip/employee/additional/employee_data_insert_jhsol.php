<!-- employee_data_insert -->
<!DOCTYPE html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<html>
<body align="center">
<h3>Form Fill up</h3>
<form name="formSubmit" id="formSubmit"  method="POST" action="employee_data_save.php" enctype="multipart/form-data">
<br>
First name:
<br><input type="text" name="first_name">
<br>
Father name:
<br><input type="text" name="father_name">
<br>
Email ID:
<br><input type="email" name="email" required>
<br>
User name:
<br><input type="text" name="user_name">
<br>

Phone Number:
<br><input type="tel" name="phone_number">
<br>


Education:
<br>
<select id="edu_select" name="education" form="formSubmit">
  <option value="BE">BE</option>
  <option value="others">other</option>
</select>

<br>
Gender:
<br>
<br>
  <input type="radio" name="gender" value="male" checked> Male<br>
  <input type="radio" name="gender" value="female"> Female<br>
<br>
  DOB:
<br><input type="date" name="date_of_birth">
<br>
Address:
<br>
<textarea name="address" form="formSubmit">Enter Address </textarea>
<br><br>
Password:
<br><input type="password" name="password">
<br>
Confirm password:
<br><input type="password" name="confirm_password">
<br>
Profile Pic:
<br><input type="file" name="image">
<br>
<button>Submit</button>
</form>
</body>









</html>